#include <SFML/Graphics.hpp>
#include "SFML/Window.hpp"
#include "SFML/System.hpp"
#include <iostream>

float desiredTime = 15;
float timeElapsed = 0;

float dt = 0.001;
float g = 9.81;
float v_t = 50;

std::vector<sf::Vector2f> points;

sf::Vector3f vel = sf::Vector3f(50, 25, 5);

sf::Vector3f rk1, rk2, newVel, pos;

sf::Vector3f rk(sf::Vector3f curr);

//-------------------------------------------------MAIN FUNCTION-----------------------------------------------------------//
int main()
{
	sf::RenderWindow window(sf::VideoMode(1200, 600), "Kinematics");
	window.setFramerateLimit(1000);

	sf::CircleShape shape(10.0f);
	shape.setFillColor(sf::Color::Green);

	pos = sf::Vector3f(0, 0, 0);

	while (window.isOpen())
	{

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			if (event.KeyPressed && event.key.code == sf::Keyboard::Escape)
				window.close();
		}

		rk1 = rk(vel);
		rk2 = rk(vel + sf::Vector3f(
			2.0 / 3.0*dt * rk1.x,
			2.0 / 3.0*dt * rk1.y, 
			2.0 / 3.0*dt*rk1.z)
		);

		newVel = vel + sf::Vector3f(
			dt * (1.0 / 4.0*rk1.x + 3.0 / 4.0*rk2.x),
			dt * (1.0 / 4.0*rk1.y + 3.0 / 4.0*rk2.y),
			dt * (1.0 / 4.0*rk1.z + 3.0 / 4.0*rk2.z)
		);

		pos = pos + sf::Vector3f(
			newVel.x * dt,
			newVel.y * dt,
			newVel.z * dt
		);

		vel = newVel;

		timeElapsed += dt;

		shape.setPosition(sf::Vector2f(pos.x + 200, 300 - pos.y));

		window.clear();
		window.draw(shape);
		window.display();
	}

	return 0;

}

sf::Vector3f rk(sf::Vector3f curr)
{
	return sf::Vector3f(
		-1 * g / v_t * curr.x,
		curr.y = -1 * g / v_t * curr.y - g,
		-1 * g / v_t * curr.z
	);
}