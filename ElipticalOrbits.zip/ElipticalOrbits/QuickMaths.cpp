#include "QuickMaths.h"
#include <iostream>
float QuickMaths::magnitude(sf::Vector2f inputVector)
{
	return float (pow(pow(inputVector.x, 2) + pow(inputVector.y, 2), 0.5));
}

float QuickMaths::magnitudeDifference(sf::Vector2f leftVector, sf::Vector2f rightVector)
{
	return float (pow(pow(leftVector.x - rightVector.x, 2) + pow(leftVector.y - rightVector.y, 2), 0.5));
}

sf::Vector2f QuickMaths::difference(sf::Vector2f leftVector, sf::Vector2f rightVector)
{
	return sf::Vector2f(leftVector.x - rightVector.x, leftVector.y - rightVector.y);
}

sf::Vector2f QuickMaths::toPolar(sf::Vector2f &toBeMadePolar) //(x, y) -> (r, theta)
{
	return sf::Vector2f(magnitude(toBeMadePolar), atan(toBeMadePolar.y/toBeMadePolar.x));
}

sf::Vector2f QuickMaths::toCartesian(sf::Vector2f &toBeMadeCartesian, float alpha) //(r, theta) -> (x, y)
{
	return sf::Vector2f(toBeMadeCartesian.x*cos(toBeMadeCartesian.y + alpha), toBeMadeCartesian.x*sin(toBeMadeCartesian.y + alpha));
}
