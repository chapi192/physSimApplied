#pragma once

#include "CelestialBody.h"

class ColorChanger
{
public:
	void colorFromDt(CelestialBody &planet, float dt);
};

