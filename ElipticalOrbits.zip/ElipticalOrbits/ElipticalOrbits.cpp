#include "SFML/Graphics.hpp"
#include "SFML/Window.hpp"
#include "SFML/System.hpp"
#include <iostream>
#include <Windows.h>
#include <cmath>

#include "PlanetController.h"
#include "CelestialBody.h"
#include "RangeKutta4thOrder.h"
#include "ClickLogic.h"
#include "ColorChanger.h"

#define _USE_MATH_DEFINES

void Update(CelestialBody &satelite, float dt);
void UpdateText(sf::Text &text, double dt);

RangeKutta4thOrder rkCalc;
PlanetController planetController;
ClickLogic clicklogic;
ColorChanger colorChanger;

double dt = 1.0f / 100.0f;

//-------------------------------------------------MAIN FUNCTION-----------------------------------------------------------//
int main()
{
	sf::Vector2i screenSize(GetSystemMetrics(SM_CXSCREEN) * 2 / 3, GetSystemMetrics(SM_CYSCREEN) * 2 / 3);
	sf::RenderWindow window(sf::VideoMode(screenSize.x, screenSize.y), "ElipticalOrbits");
	window.setFramerateLimit(100);

	sf::Font font;
	font.loadFromFile("Fonts/times.ttf");
	sf::Text text = sf::Text("", font, 15);

	CelestialBody sun = CelestialBody(333000*100, 35, sf::Color::Yellow, sf::Vector2f(screenSize.x / 2, screenSize.y / 2));

	int count = 0;
	float alpha;

	//------------------------------Window Loop -------------------------------//
	while (window.isOpen())
	{
		count++;

		float alpha = (rand() % (count + 1)) / (2*3.1415);
		float eccentricity = (rand() % 100) / 100.0;
		float semimajor = (rand() % 175) + 60;

		clicklogic.clickOncePerSecond(count);

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			if (event.KeyPressed && event.key.code == sf::Keyboard::Escape)
				window.close();
		}

		clicklogic.keyPress(event, dt);

		if (event.type == sf::Event::MouseButtonPressed && clicklogic.readyForNewPlanet)
		{
			count = 0;
			std::cout << "building planet" << std::endl;
			planetController.addPlanet(100, 10, sf::Color::Red, sf::Vector2f(screenSize.x / 2 + 120, screenSize.y / 2), sun, alpha, eccentricity, semimajor);
		}

		//-------------------------------Drawing------------------------------//
		window.clear();

		for (int i = 0; i < planetController.celestialMap.size(); i++)
		{
			Update(planetController.celestialMap[i], dt);
			window.draw((planetController.celestialMap[i]).body);
		}

		UpdateText(text, dt);

		window.draw(text);
		window.draw(sun.body);

		window.display();

	}

	return 0;

}

void Update(CelestialBody &satelite, float dt)
{
	rkCalc.dTheta(satelite, dt);
	colorChanger.colorFromDt(satelite, dt);
	satelite.updateCartesian(satelite.alpha);
}

void UpdateText(sf::Text &text, double dt)
{
	text.setString("dt: " + std::to_string(dt));
}