#pragma once

#include "SFML/Window.hpp"

class ClickLogic
{
public:
	void clickOncePerSecond(int &count);
	void keyPress(sf::Event event, double &dt);

	bool readyForNewPlanet = false;

	bool pressingUp;
	bool pressingDown;
	
	float dtdt = 0;
};

