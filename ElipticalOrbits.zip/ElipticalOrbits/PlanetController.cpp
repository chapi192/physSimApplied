#include "PlanetController.h"
#include "CelestialBody.h"
#include <string>
#include <iostream>

void PlanetController::addPlanet(float desiredMass, float desiredRadius, sf::Color color, sf::Vector2f initialCenterPosition, CelestialBody sun, float alpha, float eccentricity, float semimajor)
{
	CelestialBody toAdd = CelestialBody(desiredMass, desiredRadius, color, initialCenterPosition);
	toAdd.alpha = alpha;
	toAdd.eccentricity = eccentricity;
	toAdd.semimajorA = semimajor;
	toAdd.tether(sun, toAdd);
	celestialMap.push_back(toAdd);
}