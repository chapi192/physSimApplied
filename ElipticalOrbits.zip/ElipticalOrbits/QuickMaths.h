#pragma once

#include "SFML/System.hpp"
#include "SFML/Graphics.hpp"
#include <math.h>

class QuickMaths
{
public:
	float magnitude(sf::Vector2f inputVector);
	float magnitudeDifference(sf::Vector2f leftVector, sf::Vector2f rightVector);

	sf::Vector2f difference(sf::Vector2f leftVector, sf::Vector2f rightVector);

	sf::Vector2f toPolar(sf::Vector2f &toBeMadePolar);
	sf::Vector2f toCartesian(sf::Vector2f &toBeMadeCartesian, float alpha);

};

