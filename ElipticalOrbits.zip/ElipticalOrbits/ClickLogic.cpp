#include "ClickLogic.h"

void ClickLogic::clickOncePerSecond(int & count)
{
	if (count > 50)
	{
		readyForNewPlanet = true;
	}
	else
		readyForNewPlanet = false;
}

void ClickLogic::keyPress(sf::Event event, double &dt)
{
	if (dt > -0.75 && dt < 0.75);
		if (event.type == sf::Event::KeyPressed && event.KeyPressed && !pressingDown)
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			{
				if (dtdt < 0.03)
					dtdt += 0.00005;
				dt += 0.001 + dtdt;
				pressingUp = true;
			}
			else
			{
				dtdt = 0;
				pressingUp = false;
			}
		if (event.type == sf::Event::KeyPressed && event.KeyPressed && !pressingUp)
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			{
				if(dtdt < 0.03)
					dtdt -= 0.00005;
				dt -= 0.001 - dtdt;
				pressingDown = true;
			}
			else
			{
				dtdt = 0;
				pressingDown = false;
			}
		if (dt > 0.75)
			dt = 0.75;
		if (dt < -0.75)
			dt = -0.75;
}
