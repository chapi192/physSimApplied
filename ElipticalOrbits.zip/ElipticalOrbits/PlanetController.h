#pragma once

#include "CelestialBody.h"

class PlanetController
{
public:
	std::vector<CelestialBody> celestialMap;

	int count = 0;

	void addPlanet(float desiredMass, float desiredRadius, sf::Color color, sf::Vector2f initialCenterPosition, CelestialBody sun, float alpha, float eccentricity, float semimajor);
};