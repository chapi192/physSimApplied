#pragma once

#include "SFML/System.hpp"
#include "SFML/Graphics.hpp"

#define _USE_MATH_DEFINES
#include <cmath>

#include "CelestialBody.h"
class RangeKutta4thOrder
{
public:
	void dTheta(CelestialBody &planet, float dt);
	float fOfTheta(CelestialBody planet, float theta);
};

