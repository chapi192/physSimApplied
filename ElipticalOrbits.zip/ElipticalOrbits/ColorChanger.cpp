#include "ColorChanger.h"

void ColorChanger::colorFromDt(CelestialBody & planet, float dt)
{
	planet.body.setFillColor(sf::Color(100 - 50 * dt, 100 + 50 * dt, 0));
}