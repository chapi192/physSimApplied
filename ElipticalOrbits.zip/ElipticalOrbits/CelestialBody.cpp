#include "CelestialBody.h"
#include <math.h>
#include <iostream>

CelestialBody::CelestialBody(float desiredMass, float desiredRadius, sf::Color color, sf::Vector2f initialCenterPosition)
{
	mass = desiredMass;
	body.setRadius(desiredRadius);

	setCartesianCenterPosition(initialCenterPosition);
	setTrueCartesianPosition(sf::Vector2f(initialCenterPosition.x - desiredRadius, initialCenterPosition.y - desiredRadius));

	body.setFillColor(color);
}

void CelestialBody::setPolarPosition(sf::Vector2f pos) //polar position about the sun
{
	polarPosition = pos;
}

void CelestialBody::setTrueCartesianPosition(sf::Vector2f pos) //the computer's location for the object
{
	body.setPosition(pos);
}

void CelestialBody::setCartesianCenterPosition(sf::Vector2f pos) //location of the center from the window perspective
{
	cartesianCenter = pos;
}

void CelestialBody::setRelativeCartesianCenter(sf::Vector2f pos) //location of the planet's center from the sun's perspective
{
	relativeCartesianCenter = pos;
}

void CelestialBody::updatePolar(void)
{
	setPolarPosition(quickmath.toPolar(relativeCartesianCenter));
}

void CelestialBody::updateCartesian(float alpha)
{
	setRelativeCartesianCenter(sf::Vector2f(quickmath.toCartesian(polarPosition, alpha).x, quickmath.toCartesian(polarPosition, alpha).y));

	//maybe have a root loction vector in the future. For now, I know that the sun's center is located at (640, 360) with radius 35
	setCartesianCenterPosition(sf::Vector2f(relativeCartesianCenter.x + 640, relativeCartesianCenter.y + 360));
	setTrueCartesianPosition(sf::Vector2f(cartesianCenter.x - body.getRadius(), cartesianCenter.y - body.getRadius()));
}

void CelestialBody::tether(CelestialBody &root, CelestialBody &satelite)
{
	float dist = quickmath.magnitudeDifference(satelite.cartesianCenter, root.cartesianCenter);
	sf::Vector2f diff = quickmath.difference(satelite.cartesianCenter, root.cartesianCenter);

	if(diff.y < 0)
		satelite.setPolarPosition(sf::Vector2f(dist, atan(diff.y/diff.x) + 3.14));	
	else 
		satelite.setPolarPosition(sf::Vector2f(dist, atan(diff.y / diff.x)));

	satelite.setRelativeCartesianCenter(diff);
	satelite.startRad = relativeCartesianCenter.x;

	satelite.tetheredMass = root.mass;
	satelite.tetheredRadius = root.body.getRadius();
	satelite.bigM = satelite.mass + satelite.tetheredMass;

	satelite.Period = 2 * M_PI * pow(semimajorA, 3.0f / 2.0f) / pow(6.67408 * pow(10, -3)* bigM, 0.5);
}