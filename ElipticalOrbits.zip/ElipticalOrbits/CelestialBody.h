#pragma once

#include "SFML/System.hpp"
#include "SFML/Graphics.hpp"
#include "QuickMaths.h"
#define _USE_MATH_DEFINES
#include <cmath>

class CelestialBody
{
public:
	CelestialBody(float desiredMass, float desiredRadius, sf::Color color, sf::Vector2f initialCenterPosition);

	QuickMaths quickmath;

	sf::CircleShape body; 
	//body will have position, radius
	//body position is the 'true' position

	sf::Vector2f polarPosition; //the polar position relative to the sun
	sf::Vector2f cartesianCenter; //the position of the center based on the window
	sf::Vector2f relativeCartesianCenter; //the position of the center based on the sun

	void tether(CelestialBody &root, CelestialBody &satelite);

	float mass;


	float tetheredMass; //mass of tethered planet
	float tetheredRadius; //radius of tethered planet
	float bigM; //mass of planet and roots
	float startRad; //the distance from our planet's center to the tethered planet's center
	float semimajorA;
	float eccentricity;
	float Period;
	float alpha;

	void setPolarPosition(sf::Vector2f pos);
	void setTrueCartesianPosition(sf::Vector2f pos);
	void setCartesianCenterPosition(sf::Vector2f pos);
	void setRelativeCartesianCenter(sf::Vector2f pos);

	void updatePolar(void);
	void updateCartesian(float alpha);
};

