#include "RangeKutta4thOrder.h"
#include <iostream>

void RangeKutta4thOrder::dTheta(CelestialBody &planet, float dt)
{
	float alpha = M_PI;

	float k1f, k2f, k3f, k4f;

	float theta = planet.polarPosition.y;

	k1f = fOfTheta(planet, theta);
	k2f = fOfTheta(planet, theta + dt * 1.0f / 2.0f * k1f);
	k3f = fOfTheta(planet, theta + dt * 1.0f / 2.0f * k2f);
	k4f = fOfTheta(planet, theta + dt * k3f);

	planet.polarPosition.y = theta + dt * (1.0f / 6.0f * (k1f + k4f) + 1.0f / 3.0f * (k2f + k3f));

	planet.polarPosition.x = planet.semimajorA * pow(1 - pow(planet.eccentricity, 2), 0.5) / (1 + planet.eccentricity * cos(planet.polarPosition.y));
}

float RangeKutta4thOrder::fOfTheta(CelestialBody planet, float theta)
{
	float toReturn = 2 * M_PI * planet.semimajorA * (1 + planet.eccentricity * cos(theta)) / (planet.Period * planet.polarPosition.x * pow(1 - pow(planet.eccentricity, 2), 0.5));
	return toReturn;
}