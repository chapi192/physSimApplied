#define _USE_MATH_DEFINES

#include <SFML/Graphics.hpp>
#include "SFML/Window.hpp"
#include "SFML/System.hpp"
#include <iostream>
#include <math.h>

#include <Windows.h>

int altitude = 0;
int count = 0;

float nozzleDiameter = 0.3; //diameter of the nozzle [m]
float nozzlePressure = 0.07 * pow(10, 6); //pressure immediately inside of the nozzle [Pa]
float massFlow = 30; // [kg/s] expelled from the nozzle
float nozzleVelocity = 2500; //the current velocity of mass flow from the nozzle [m/s]

//constants which should NOT BE CHANGED unless you are God
float pressureSeaLevel = 101.3 * 1000.0; //[Pa]
float bigG = 6.6743 * pow(10, -11); //[m ^ 3 / (ks ^ 2)]
float radiusEarth = 6371000.0; //[m]
float massEarth = 5.972 * pow(10, 24); //[kg]
float MRT = 1.24426778 * pow(10, -4) / 9.81; //[1/(m/s^2)]


float nozzleArea(float diameter),
	gravAcceleration(int height),
	atmosphericPressure(int height, float g),
	exhaustVelocity(float nozzleVel, float nozzlePres, float atmosphericPres, float nozzleArea, float massFlow),
	thrust(float massFlow, float effectiveExhaustVelocity);

float currentAccelerationGravity,
	currentAtmosphericPressure;

sf::Vector3f currentConditions;
//-------------------------------------------------MAIN FUNCTION-----------------------------------------------------------//
int main()
{
	sf::ConvexShape rocket;
	sf::ConvexShape arrow;
	sf::ConvexShape arrow2;

	rocket.setPointCount(9);
	arrow.setPointCount(8);
	arrow2.setPointCount(8);

	// define the points
	rocket.setPoint(0, sf::Vector2f(0, 0));
	rocket.setPoint(1, sf::Vector2f(5, 5));
	rocket.setPoint(2, sf::Vector2f(5, 20));
	rocket.setPoint(3, sf::Vector2f(0, 22));
	rocket.setPoint(4, sf::Vector2f(4, 27));
	rocket.setPoint(5, sf::Vector2f(-4, 27));
	rocket.setPoint(6, sf::Vector2f(0, 22));
	rocket.setPoint(7, sf::Vector2f(-5, 20));
	rocket.setPoint(8, sf::Vector2f(-5, 5));

	arrow.setPoint(0, sf::Vector2f(0, 0));
	arrow.setPoint(1, sf::Vector2f(5, 5));
	arrow.setPoint(2, sf::Vector2f(2, 5));
	arrow.setPoint(3, sf::Vector2f(2, 15));
	arrow.setPoint(4, sf::Vector2f(-2, 15));
	arrow.setPoint(5, sf::Vector2f(-2, 5));
	arrow.setPoint(6, sf::Vector2f(-5, 5));
	arrow.setPoint(7, sf::Vector2f(0, 0));

	arrow2.setPoint(0, sf::Vector2f(0, 0));
	arrow2.setPoint(1, sf::Vector2f(2, 0));
	arrow2.setPoint(2, sf::Vector2f(2, 10));
	arrow2.setPoint(3, sf::Vector2f(5, 10));
	arrow2.setPoint(4, sf::Vector2f(0, 15));
	arrow2.setPoint(5, sf::Vector2f(-5, 10));
	arrow2.setPoint(6, sf::Vector2f(-2, 10));
	arrow2.setPoint(7, sf::Vector2f(-2, 0));

	arrow2.rotate(-90);
	arrow2.setFillColor(sf::Color::Blue);

	arrow.setPosition(GetSystemMetrics(SM_CXSCREEN) * 6.0 / 10.0 - 675, GetSystemMetrics(SM_CYSCREEN) * 5.0 / 10.0);
	arrow.rotate(90);
	arrow.setFillColor(sf::Color::Red);

	rocket.setPosition(GetSystemMetrics(SM_CXSCREEN) * 6.0 / 10.0, GetSystemMetrics(SM_CYSCREEN) * 5.0 / 10.0);
	rocket.setScale(25, 25);
	rocket.rotate(90);

	sf::Vector2i screenSize(GetSystemMetrics(SM_CXSCREEN) * 9.0/10.0, GetSystemMetrics(SM_CYSCREEN) * 9.0 / 10.0);

	sf::RenderWindow window(sf::VideoMode(screenSize.x, screenSize.y), "Nozzle");
	window.setFramerateLimit(1000);

	sf::Font font;
	if (!font.loadFromFile("Fonts/times.ttf"))
		throw("COULD NOT OPEN FONT FILE");

	sf::Text text;
	text.setFont(font);
	text.setCharacterSize(35);

	sf::Text results;
	results.setFont(font);
	results.setCharacterSize(35);
	results.setPosition(650, 0);

	float initialVelocity = exhaustVelocity(nozzleVelocity, nozzlePressure, atmosphericPressure(0, gravAcceleration(0)), nozzleArea(nozzleDiameter), massFlow);
	float initialThrust = thrust(massFlow, initialVelocity);

	while (window.isOpen())
	{
		count++;
		window.clear();

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			if (event.KeyPressed && event.key.code == sf::Keyboard::Escape)
				window.close();
		}
		if (altitude < 100000 + 10)
		{
			currentAccelerationGravity = gravAcceleration(altitude);
			currentAtmosphericPressure = atmosphericPressure(altitude, currentAccelerationGravity);

			currentConditions.x = altitude;
			currentConditions.y = exhaustVelocity(nozzleVelocity, nozzlePressure, currentAtmosphericPressure, nozzleArea(nozzleDiameter), massFlow);
			currentConditions.z = thrust(massFlow, currentConditions.y);
/*
			std::cout << "Altitude: " << currentConditions.x << "\n     " << currentConditions.y << "\n     " << currentConditions.z << std::endl;*/

			text.setString(
				  "Altitude:_____" + std::to_string(currentConditions.x) + " meters\n"
				+ "Nozzle Vel:___" + std::to_string(currentConditions.y) + " m/s\n"
				+ "Thrust:______" + std::to_string(currentConditions.z) + " N");
		}
		else
		{
			results.setString(
				  "Init Thrust:______" + std::to_string(initialThrust) + " N\n"
				+ "Delta Thrust:_____" + std::to_string(currentConditions.z - initialThrust) + " N\n"
				+ "Init Nozzle Vel:___" + std::to_string(initialVelocity) + " m/s\n"
				+ "Delta Nozzle Vel:__" + std::to_string(currentConditions.y - initialVelocity) + " m/s");
		}

		arrow.setScale(5.0, 10.0 + 10.0 * (currentConditions.z - initialThrust) / 8000.0);
		window.draw(arrow);

		arrow2.setScale(-3, -5.0 - 5.0 * (currentConditions.y - initialVelocity) / 250.0);
		arrow2.setPosition(GetSystemMetrics(SM_CXSCREEN) * 6.0 / 10.0 - 675, GetSystemMetrics(SM_CYSCREEN) * 5.85 / 10.0);
		window.draw(arrow2);
		arrow2.setPosition(GetSystemMetrics(SM_CXSCREEN) * 6.0 / 10.0 - 675, GetSystemMetrics(SM_CYSCREEN) * 4.15 / 10.0);
		window.draw(arrow2);

		window.draw(rocket);
		window.draw(text);
		window.draw(results);


		window.display();

		altitude += 5;

	}

	return 0;

}

float nozzleArea(float diameter)
{
	return M_PI * pow((diameter / 2.0), 2);
}

float gravAcceleration(int height)
{
	return bigG * massEarth / pow((radiusEarth + height), 2);
}

float atmosphericPressure(int height, float g)
{
	return pressureSeaLevel * pow(M_E, -1.0 * MRT * g * height);
}

float exhaustVelocity(float nozzleVel, float nozzlePres, float atmosphericPres, float nozzleArea, float massFlow)
{
	return nozzleVel + (nozzlePres - atmosphericPres) * nozzleArea / massFlow;
}

float thrust(float massFlow, float effectiveExhaustVelocity)
{
	return massFlow * effectiveExhaustVelocity;
}
