#pragma once
#include "SFML/System.hpp"
#include "SFML/Graphics.hpp"

class CelestialBody
{
public:
	CelestialBody();
	CelestialBody(sf::Vector2i location, float magnitude, float theta);

	sf::CircleShape body;

	float mass = 0;

	sf::Vector2f polarPosition = sf::Vector2f (0, 0);

	float orbitalDistance;

	sf::Vector2f position;
	sf::Vector2f velocity;
	sf::Vector2f acceleration;

	void setMass(float m);
	void setPosition(float a, float b);
	void setVelocity(float a, float b);
	void setAcceleration(float a, float b);

	void setPolarPosition(float a, float b);

	void currentPosition(void);
	void currentVelocity(void);
	void currentAcceleration(void);
	void currentState(void);

	void currentPolarPosition(void);
};

