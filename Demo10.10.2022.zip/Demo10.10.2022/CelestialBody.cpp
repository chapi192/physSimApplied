#include "CelestialBody.h"
#include <iostream>
#include <math.h>

CelestialBody::CelestialBody()
{
	body.setRadius(5);
	setPosition(100 - body.getRadius() , 100 - body.getRadius());
}

CelestialBody::CelestialBody(sf::Vector2i location, float magnitude, float theta)
{
	body.setRadius(5);
	setPosition(location.x - body.getRadius(), location.y - body.getRadius());
	orbitalDistance = magnitude;

	setPolarPosition(magnitude, theta);

	body.setFillColor(sf::Color::Green);
	body.setOutlineColor(sf::Color::White);
}


void CelestialBody::setMass(float m)
{
	mass = m;
}

void CelestialBody::setPosition(float a, float b)
{
	body.setPosition(a, b);
	position.x = a;
	position.y = b;
}

void CelestialBody::setPolarPosition(float a, float b)
{
	polarPosition.x = a;
	polarPosition.y = b;
}

void CelestialBody::setVelocity(float a, float b)
{
	velocity.x = a;
	velocity.y = b;
}

void CelestialBody::setAcceleration(float a, float b)
{
	acceleration.x = a;
	acceleration.y = b;
}

void CelestialBody::currentPosition(void)
{
	sf::Vector2f loc = body.getPosition();
	std::cout << "Position: (" << loc.x << ", " << loc.y << ")" << std::endl;
}

void CelestialBody::currentVelocity(void)
{
	std::cout << "Velocity: (" << velocity.x << ", " << velocity.y << ")" << std::endl;
}

void CelestialBody::currentAcceleration(void)
{
	std::cout << "Velocity: (" << acceleration.x << ", " << acceleration.y << ")" << std::endl;
}

void CelestialBody::currentState(void)
{
	currentPosition();
	currentVelocity();
	std::cout << "Mass: " << mass << std::endl;
}

void CelestialBody::currentPolarPosition(void)
{
	std::cout << "Polar Position: (" << polarPosition.x << ", " << polarPosition.y << ")" << std::endl;
}