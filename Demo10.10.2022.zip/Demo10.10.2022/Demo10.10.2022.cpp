#include "SFML/Graphics.hpp"
#include "SFML/Window.hpp"
#include "SFML/System.hpp"
#include <iostream>
#include <Windows.h>//required to get dimensions of monitor
#include "CelestialBody.h"
#include <math.h>
#include "PlanetController.h"

//how often the computer refreshes the window per second
int frameRate = 100;

//dt is set at a fraction of the framerate. So instead of updating where it should be an arbitrary number of times, it updates where we should be 
//exactly per frame
double dt = 1 / ((double)frameRate);
double dtdt = 0;

sf::Vector2i screenSize(GetSystemMetrics(SM_CXSCREEN) * 2 / 3, GetSystemMetrics(SM_CYSCREEN) * 2 / 3);
sf::Color color;

PlanetController planetController;

float magnitude = 100.0f;
float theta = 0;

void pointerUpdate(CelestialBody* planet, CelestialBody sun, sf::Color color);

//-------------------------------------------------MAIN FUNCTION-----------------------------------------------------------//
int main()
{
	sf::RenderWindow window(sf::VideoMode(screenSize.x, screenSize.y), "Kinematics");
	window.setFramerateLimit(frameRate);

	CelestialBody sun;
	sun.body.setFillColor(sf::Color::Yellow);
	sun.body.setRadius(25);
	sun.body.setPosition(screenSize.x / 2 - sun.body.getRadius(), screenSize.y / 2 - sun.body.getRadius());
	sun.mass = 500000;

	CelestialBody planetA;
	planetA.body.setFillColor(sf::Color::Blue);
	planetA.body.setRadius(4);
	planetA.mass = 5;

	sf::Font font;
	if (!font.loadFromFile("Fonts/times.ttf"))
		throw("COULD NOT OPEN FONT FILE");

	sf::Text text;
	text.setFont(font);
	text.setCharacterSize(15);

	int count = 0;
	bool ready = true;

	bool pressingUp = false;
	bool pressingDown = false;

	while (window.isOpen())
	{
		window.clear();

		count += 1;

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			if (event.KeyPressed && event.key.code == sf::Keyboard::Escape)
				window.close();
		}
		if (count % 100 == 0)
			ready = true;

		if (event.type == sf::Event::KeyPressed && event.KeyPressed && !pressingDown)
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			{
				dtdt += 0.000005;
				dt += 0.001 + dtdt;
				pressingUp = true;
				std::cout << "Up";
			}
			else
			{
				dtdt = 0;
				pressingUp = false;
			}
		if (event.type == sf::Event::KeyPressed && event.KeyPressed && !pressingUp)
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			{
				
				dtdt -= 0.000005;
				dt -= 0.001 - dtdt;
				pressingDown = true;
				std::cout << "Down";
			}
			else
			{
				dtdt = 0;
				pressingDown = false;
			}

		if (event.type == sf::Event::MouseButtonPressed && ready)
		{
			sf::Vector2i mouseLocation = sf::Mouse::getPosition(window);
			float diffX = mouseLocation.x - sun.body.getPosition().x - sun.body.getRadius();
			float diffY = mouseLocation.y - sun.body.getPosition().y - sun.body.getRadius();

			magnitude = pow(pow(diffX, 2) + pow(diffY, 2), 0.5);
			theta = std::atan(diffY / diffX);

			if (diffX < 0)
				planetController.addVectorBody(mouseLocation, magnitude, theta + 3.14);
			else 
				planetController.addVectorBody(mouseLocation, magnitude, theta);
			
			ready = false;
			count = 0;
		}
		if(dt < 2.5)
			color = sf::Color(225 - 100 * dt, 100 * dt, 0);
		for (int i = 0; i < planetController.celestialMap.size(); i++)
		{
			pointerUpdate(planetController.celestialMap[i], sun, color);
			window.draw((*planetController.celestialMap[i]).body);
		}
		
		text.setString(std::to_string(dt));



		window.draw(sun.body);
		window.draw(text);

		window.display();
	}

	return 0;

}

void pointerUpdate(CelestialBody* planet, CelestialBody sun, sf::Color color)
{
	planet->body.setFillColor(color);
	float dtheta = pow((6.67 * pow(10, -3) * sun.mass / pow(planet->orbitalDistance, 3)), 0.5);

	planet->setPolarPosition(planet->polarPosition.x, planet->polarPosition.y + dtheta * dt);

	planet->setPosition(planet->orbitalDistance * cos(planet->polarPosition.y) - planet->body.getRadius() + screenSize.x / 2,
		planet->orbitalDistance * sin(planet->polarPosition.y) - planet->body.getRadius() + screenSize.y / 2);
}
