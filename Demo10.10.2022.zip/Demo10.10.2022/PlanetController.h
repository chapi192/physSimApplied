#pragma once

#include "CelestialBody.h"

class PlanetController
{
public:
	std::vector<CelestialBody*> celestialMap;
	
	int count = 0;

	void addVectorBody(sf::Vector2i location, float magnitude, float theta);
};

