#include "PlanetController.h"
#include "CelestialBody.h"
#include <string>
#include <iostream>

void PlanetController::addVectorBody(sf::Vector2i location, float magnitude, float theta)
{
	celestialMap.push_back(new CelestialBody(location, magnitude, theta));
}